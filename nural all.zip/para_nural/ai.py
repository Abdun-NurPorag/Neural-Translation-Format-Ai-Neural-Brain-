def find_perfect_match(user_input, paragraph):
    sentences = paragraph.split('.')
    max_matches = 0
    perfect_match_sentence = ""

    for sentence in sentences:
        sentence_matches = sum(1 for word in sentence.split() if word.lower() in user_input.lower())
        if sentence_matches > max_matches:
            max_matches = sentence_matches
            perfect_match_sentence = sentence.strip()

    return perfect_match_sentence

def match_paragraph(user_input, data_file_path):
    max_matches = 0
    matching_paragraph = ""

    with open(data_file_path, 'r') as file:
        data = file.read()

    paragraphs = data.split('[/]')

    for paragraph in paragraphs:
        paragraph_matches = sum(1 for word in paragraph.split() if user_input.lower() in word.lower())

        if paragraph_matches > max_matches:
            max_matches = paragraph_matches
            matching_paragraph = paragraph

    return matching_paragraph

if __name__ == "__main__":
    user_input = input("Enter your input: ")
    data_file_path = "data.txt"  # Replace with the actual path to your data file

    matching_paragraph = match_paragraph(user_input, data_file_path)

    if matching_paragraph:
        print("#")

        perfect_match_sentence = find_perfect_match(user_input, matching_paragraph)
        if perfect_match_sentence:
            print("Perfect Match Sentence:")
            print(perfect_match_sentence)
        else:
            print("No perfect match sentence found.")
    else:
        print("No matching paragraph found.")
