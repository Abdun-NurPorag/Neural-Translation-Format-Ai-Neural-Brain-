# json_reader.py

import json

def carbon_read_json(file_path, key=None):
    """Read a JSON file and return its object or a specific value."""
    with open(file_path, 'r') as file:
        json_data = json.load(file)

    if key is not None:
        # If a key is specified, return the corresponding value
        value = json_data
        keys = key.split('.')
        for k in keys:
            if k in value:
                value = value[k]
            else:
                raise KeyError(f"Key '{key}' not found in the JSON object.")
        return value
    else:
        # If no key is specified, return the entire JSON object
        return json_data
#####
####
####         write any file,read any file, append any file
# FileWriter.py

def carbon_write_file(file_path, data):
    with open(file_path, 'w') as file:
        file.write(data)

def carbon_read_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def carbon_append_file(file_path, data):
    with open(file_path, 'a') as file:
        file.write(data)

###objext check
import json

def carbon_object_check(file_path, object_name):
    try:
        with open(file_path, 'r') as json_file:
            data = json.load(json_file)
            return object_name in data
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return False
    except json.JSONDecodeError:
        print(f"Error: Unable to decode JSON in file '{file_path}'.")
        return False
    except Exception as e:
        print(f"Error: {e}")
        return False


