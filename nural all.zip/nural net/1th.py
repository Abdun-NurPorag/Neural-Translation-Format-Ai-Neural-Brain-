import random
noun={
"1":"porag",
"2":"Abdun",
"3":"Nur",
"4":"Tom",
"5":"Jerry",
"6":"Zack",
"7":"",
}
pronoun={
"1":"he",
"2":"she",
"3":"they",
"4":"we",
"5":"us",
"6":"them"
}
verb={
"1":"go",
"2":"walk",
"3":"move",
"4":"like",
"5":"do",
"6":"see"
}
ax_verb={
"1":"am",
"2":"is",
"3":"are",
"4":"was",
"5":"were",
"5":"have",
"6":"has",

}
preposition={
"1":"to",
"2":"from",
"3":"at",
"4":"up",
"5":"behind",
"6":"top",
}
while True:
    action=input()
    word_key=random.randint(1,6)
    gen_noun=random.randint(1,6)
    gen_pronoun=random.randint(1,6)
    gen_verb=random.randint(1,6)
    gen_axverb=random.randint(1,6)
    gen_preposition=random.randint(1,6)
    str_noun=str(gen_noun)
    str_pronoun=str(gen_pronoun)
    str_verb=str(gen_verb)
    str_axverb=str(gen_axverb)
    str_preposition=str(gen_preposition)
    print(str_noun,str_pronoun,str_verb, str_axverb,str_preposition)
#make sentence
    sentence=f"{noun[str_noun]} {pronoun[str_pronoun]} {ax_verb[str_axverb]} {verb[str_verb]}"
    ##spliting text
    split_text=sentence.split()
    print(sentence)
    print(split_text)
    