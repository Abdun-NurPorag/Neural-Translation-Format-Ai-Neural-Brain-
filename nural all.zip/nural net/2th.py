import random
from aijson import carbon_read_json
##subject read
while True:
    action=input()
    subject_path="subject.json"
    subject_key=str(random.randint(1,100))
    subject=carbon_read_json(subject_path,subject_key)
##ax verb read
    ax_verb_path="ax_verb.json"
    ax_verb_key=str(random.randint(1,100))
    ax_verb=carbon_read_json(ax_verb_path,ax_verb_key)
##verb read
    verb_path="verb.json"
    verb_key=str(random.randint(1,100))
    verb=carbon_read_json(verb_path,verb_key)
##read object
    object_path="object.json"
    object_key=str(random.randint(1,100))
    object=carbon_read_json(object_path,object_key)
####
#####    show ai output
    output=f"{subject} {ax_verb} {verb} {object}"
##show the output code like 1 1 2 1
    output_key=f"{subject_key} {ax_verb_key} {verb_key} {object_key}"
    print(output_key)
    print(output)
    ## adding rule for ax_currection
    ax_verb_type_file=open("ax_verb_type.txt","r")
    ax_type_read=ax_verb_type_file.read()
    if ax_verb in ax_type_read:
        print("Ax verb is past tence")
        past_ax_verb_path=""
        
         
 
##