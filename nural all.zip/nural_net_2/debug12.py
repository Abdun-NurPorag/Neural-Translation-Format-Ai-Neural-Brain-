from carbon_ai import read_obj_value

# Assuming read_obj_value returns the values from the "noun.json" file
value = read_obj_value("noun.json")

# Get user input
user_input = input("Enter a space-separated list of words: ")

# Split the user input into a list of words
words = user_input.split()

# Check if each word is in the values from the JSON file
for word in words:
    if word in value:
        print(f"{word}: True")
    else:
        print(f"{word}: False")
        
for word in words:
    if word in value and noun_obj and pronoun_obj and ax_verb_obj and verb_obj  or preposition_obj or obj_obj:
        print("###All word match")
                
else:
        print("##Word is not exist")
                
        
