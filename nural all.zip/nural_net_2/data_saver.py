from carbon_ai import carbon_write_file
while True:
    action=input()
    a=input("key::")
    b=input("Value::")
    file=">"
    carbon_append_file("noun.json",file)