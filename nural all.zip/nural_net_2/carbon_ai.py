# json_reader.py

import json

def carbon_read_json(file_path, key=None):
    """Read a JSON file and return its object or a specific value."""
    with open(file_path, 'r') as file:
        json_data = json.load(file)

    if key is not None:
        # If a key is specified, return the corresponding value
        value = json_data
        keys = key.split('.')
        for k in keys:
            if k in value:
                value = value[k]
            else:
                raise KeyError(f"Key '{key}' not found in the JSON object.")
        return value
    else:
        # If no key is specified, return the entire JSON object
        return json_data
#####
####
####         write any file,read any file, append any file
# FileWriter.py

def carbon_write_file(file_path, data):
    with open(file_path, 'w') as file:
        file.write(data)

def carbon_read_file(file_path):
    with open(file_path, 'r') as file:
        return file.read()

def carbon_append_file(file_path, data):
    with open(file_path, 'a') as file:
        file.write(data)
def read(file_name):
    file=open(file_name,"r")
    return file.read()

###objext value read
def read_obj_value(file_name):
    with open(file_name,"r")as file:
        format_to_json=json.load(file)
        obj_value=format_to_json.values()
        return obj_value
