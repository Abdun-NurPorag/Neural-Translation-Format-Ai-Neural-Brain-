from flask import Flask
from neural import flask_sentence_show

app = Flask(__name__)

@app.route("/")
def main():
    result = flask_sentence_show()
    return result

if __name__ == "__main__":
    app.run(debug=True)
