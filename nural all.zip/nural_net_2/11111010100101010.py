import random
import json

def match_words_in_db(user_input):
    with open("db.txt", "r") as db:
        db_content = json.load(db)

    input_words = user_input.split()
    
    match_count = {}
    
    for line, text in db_content.items():
        for word in input_words:
            if word in text:
                match_count[line] = match_count.get(line, 0) + 1

    if match_count:
        max_matches_line = max(match_count, key=match_count.get)
        print(f"Best matching line: {max_matches_line}")
        print(f"Random text from the line: {db_content[max_matches_line][random.randint(0, len(db_content[max_matches_line])-1)]}")
    else:
        print("No matches found")

if __name__ == "__main__":
    user_input = input("Enter your input: ")
    match_words_in_db(user_input)
