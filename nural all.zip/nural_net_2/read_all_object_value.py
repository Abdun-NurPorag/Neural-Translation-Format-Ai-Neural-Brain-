import json

# Open the JSON file
with open('noun.json', 'r') as file:
    # Load the JSON data
    data = json.load(file)

# Iterate through the values and print them
for key, value in data.items():
    print(f"{key}: {value}")

# Get user input
a = input("Enter a value: ")

# Check if user input is in the values
if a in data.values():
    print("True")
else:
    print("Wrong")
