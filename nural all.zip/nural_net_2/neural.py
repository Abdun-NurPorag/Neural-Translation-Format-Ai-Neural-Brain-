import json
import random
from carbon_ai import carbon_read_file
from carbon_ai import carbon_write_file
from carbon_ai import carbon_append_file
from carbon_ai import read
from carbon_ai import carbon_read_json
from read_obj_value import noun_obj_value
from read_obj_value import pronoun_obj_value
from read_obj_value import verb_obj_value
from read_obj_value import ax_verb_obj_value
from read_obj_value import preposition_obj_value
from read_obj_value import adj_obj_value
from read_obj_value import sub_obj_value
from read_obj_value import obj_obj_value
## sub
while True:
    action=input()
    sub_path="subject.json"
    sub_key=str(random.randint(1,100))
    sub=carbon_read_json(sub_path,sub_key)
##obj
    obj_path="object.json"
    obj_key=str(random.randint(1,100))
    obj=carbon_read_json(obj_path,obj_key)
##ax verb
    ax_verb_path="ax_verb.json"
    ax_verb_key=str(random.randint(1,100))
    ax_verb=carbon_read_json(ax_verb_path,        ax_verb_key)
##adj
    adj_path="adjective.json"
    adj_key=str(random.randint(1,100))
    adj=carbon_read_json(adj_path,adj_key)
##noun
    noun_path="noun.json"
    noun_key=str(random.randint(1,100))
    noun=carbon_read_json(noun_path,    noun_key)
##pronoun
    pronoun_path="pronoun.json"
    pronoun_key=str(random.randint(1,100))
    pronoun=carbon_read_json(pronoun_path,    pronoun_key)
##preposition
    preposition_path="preposition.json"
    preposition_key=str(random.randint(1,100))
    preposition=carbon_read_json(preposition_path,preposition_key)
## wh question
    whq_path="whquestion.json"
    whq_key=str(random.randint(1,1))
    whq=carbon_read_json(whq_path,whq_key)
## word dictionary
    dictionary_path="dictionary.json"
    dictionary_key=str(random.randint(1,100))
    dictionary=carbon_read_json(dictionary_path,dictionary_key)
##verb
    verb_path="verb.json"
    verb_key=str(random.randint(1,100))
    verb=carbon_read_json(verb_path,verb_key)
###reading verb
    present_ax=read("verb_file/present_tense.txt")
    past_ax=read("verb_file/past_tense.txt")
    perfect_ax=read("verb_file/perfect_tense.txt")
    continues_ax=read("verb_file/continues_tense.txt")
    model_ax=read("verb_file/model_ax_verb.txt")
    ##check ax verb type
    if ax_verb in present_ax:
    #affermative sentence
    ## modify {verb} with {present_form_verb}
        present_form_path="form/present_form.json"
        present_form_key=str(random.randint(1,100))
        present_form=carbon_read_json(present_form_path,present_form_key)
        sentence=f"[present tence]={sub} {ax_verb} {present_form} {obj}  \n [{sub_key} {ax_verb_key} {present_form_key} {obj_key}]"
        print(sentence)
    #################
    ##########  here need to add condition for do and dose #######
    #################    
    elif ax_verb in past_ax:
    #using past form
    #affermative
        past_form_path="form/past_form.json"
        past_form_key=str(random.randint(1,100))
        past_form=carbon_read_json(past_form_path,past_form_key)
        sentence=f"[past-tence]={sub} {ax_verb} {past_form} {preposition} {obj} \n [{sub_key} {ax_verb_key} {past_form_key} {preposition_key} {obj_key}]"
        print(sentence)
    elif ax_verb in perfect_ax:
    #affermative
        perfect_form_path="form/perfect_form.json"
        perfect_form_key=str(random.randint(1,100))
        perfect_form=carbon_read_json(perfect_form_path,perfect_form_key)
        sentence=f"[perfect-form]=={sub} {ax_verb} {perfect_form} {preposition} {obj}\n [{sub_key} {ax_verb_key} {perfect_form_key} {preposition_key} {obj_key}]"
        print(sentence)
    elif ax_verb in continues_ax:
        continues_form_path="form/continues_form.json"
        continues_form_key=str(random.randint(1,100))
        continues_form=carbon_read_json(continues_form_path,continues_form_key)
        sentence=f"[continues-tence]={sub} {ax_verb} {continues_form} {preposition} {obj}\n[{sub_key} {ax_verb_key} {continues_form_key} {preposition_key} {obj_key}]"
        print(sentence)
    elif ax_verb in model_ax:
    ##this i snot neet because verb 1
        sentence=f"[model  verb]={sub} {ax_verb} {verb} {preposition} {obj}\n[{sub_key} {ax_verb_key} {verb_key} {preposition_key} {obj_key}]"
        print(sentence)
##printinf full sentence
    def show_full_sentence():
        sentence=f"{sub}=[{sub_key}], {obj}=[{obj_key}],{ax_verb}=[{ax_verb_key}],{verb}=[{verb_key}],{adj}=[{adj_key}],{preposition}=[{preposition_key}],{noun}=[{noun_key}],{pronoun}=[{pronoun_key}],{dictionary}=[{dictionary_key}]"
        print(sentence)
        #print(sentence_key)
    show_full_sentence()
    describe_sentence=f""
    print(describe_sentence)
    ####
    #### take use input
    if action=="1":
        print("_________________________")
        print("#@user_input_section::")
        command=input("Enter your command::") 
        open_ng_command=read("command/ng_sentence_command.txt")
        if command in open_ng_command:
            print("##########\nCommand for negative sentence")
            ng_sentence=f"{sub} {ax_verb}not {verb} {preposition} {obj} \n{sub_key} {ax_verb_key} {verb_key} {preposition_key} {obj_key} "
            print(ng_sentence)
        else:
            print("####This is not negative command#####")
    if action=="2":
        print("############")
        print("Sentence checker on:")
        sentence=input("Enter sentence::")
        ###read obj value
        noun_obj=noun_obj_value()
        pronoun_obj=pronoun_obj_value()
        verb_obj=verb_obj_value()
        ax_verb_obj=ax_verb_obj_value()
        preposition_obj=preposition_obj_value()
        adj_obj=adj_obj_value()
        sub_obj=sub_obj_value()
        obj_obj=obj_obj_value()
        #
        split_sentence=sentence.split()
        every_word=split_sentence
        for word in every_word:
            if word in ax_verb_obj:
                print("###All word match")
                
            else:
                print("##Word is not exist")
    if action=="3":
        print("Working")
    def flask_sentence_show():
        sentence=f"{sub} {ax_verb} {verb} {obj}\n[{sub_key}],[{ax_verb_key}],[{verb_key}],[{obj_key}]"
        print(sentence)
        return sentence;
    flask_sentence_show()