import json
def noun_obj_value():
    with open("noun.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def pronoun_obj_value():
    with open("pronoun.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def ax_verb_obj_value():
    with open("ax_verb.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def verb_obj_value():
    with open("verb.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def preposition_obj_value():
    with open("preposition.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def adj_obj_value():
    with open("adjective.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def sub_obj_value():
    with open("subject.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def obj_obj_value():
    with open("object.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
def database_obj_value():
    with open("database.json","r")as file:
        file_read=json.load(file)
        obj_value=file_read.values()
        return obj_value
       